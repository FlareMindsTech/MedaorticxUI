import React from 'react';
import { motion } from 'framer-motion';

export const FloatingCard3D = ({
  title,
  value,
  sub,
  up,
  icon,
  iconBg,
  tilt = { rx: 8, ry: -12 },
  positionClass = '',
  delay = 0,
}) => {
  const isLeft = tilt.ry < 0;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9, y: 10 }}
      animate={{ opacity: 1, scale: 1, y: [0, -10, 0] }}
      transition={{
        opacity: { duration: 0.5, delay },
        scale: { duration: 0.5, delay },
        y: {
          duration: 5,
          repeat: Infinity,
          repeatType: 'mirror',
          ease: 'easeInOut',
          delay,
        },
      }}
      style={{
        transform: `perspective(1000px) rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg)`,
      }}
      className={`absolute z-10 bg-white/90 backdrop-blur-md rounded-2xl p-3.5 ${
        isLeft ? 'card-extrusion-left' : 'card-extrusion-right'
      } ${positionClass} transform-style-3d border border-white/60 transition-transform duration-300 hover:scale-105`}
    >
      {icon ? (
        <div className="flex items-center gap-3 min-w-[190px]">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0 shadow-sm translate-z-10"
            style={{ background: iconBg || '#E9EEFF' }}
          >
            {icon}
          </div>
          <div>
            <div className="font-bold text-ink text-sm leading-tight">{title}</div>
            <div className="text-[0.7rem] text-grayLight font-medium">{sub}</div>
          </div>
        </div>
      ) : (
        <div className="min-w-[145px]">
          <div className="text-[0.72rem] text-grayLight font-medium mb-1">{title}</div>
          <div className="text-[1.1rem] font-extrabold text-ink flex items-center gap-1.5 leading-none">
            {value}
            {up && <span className="text-emerald-500 text-xs font-bold">▲</span>}
          </div>
          <div className="text-[0.68rem] text-grayLight mt-1">{sub}</div>
        </div>
      )}
    </motion.div>
  );
};
