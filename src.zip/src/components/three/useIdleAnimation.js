import { useFrame } from '@react-three/fiber';

export const useIdleAnimation = (groupRef, rimIndigoRef, rimTealRef, armLRef, armRRef) => {
  const BASE_Y = -1.08;

  useFrame((state) => {
    const t = state.clock.getElapsedTime();

    if (groupRef.current) {
      // Idle breathing bob
      groupRef.current.position.y = BASE_Y + Math.sin(t * 1.1) * 0.045;
      // Gentle Y-axis turn facing both sides
      groupRef.current.rotation.y = Math.sin(t * 0.45) * 0.32;
    }

    // Subtle arm sway
    if (armLRef?.current) {
      armLRef.current.rotation.z = Math.sin(t * 1.1) * 0.02;
    }
    if (armRRef?.current) {
      armRRef.current.rotation.z = Math.sin(t * 1.1 + Math.PI) * 0.02;
    }

    // Pulsing rim lights
    if (rimIndigoRef?.current) {
      rimIndigoRef.current.intensity = 1.0 + Math.sin(t * 1.6) * 0.15;
    }
    if (rimTealRef?.current) {
      rimTealRef.current.intensity = 1.0 + Math.cos(t * 1.4) * 0.15;
    }
  });
};
