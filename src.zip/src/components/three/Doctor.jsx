import React, { useRef, useMemo } from 'react';
import * as THREE from 'three';
import { useIdleAnimation } from './useIdleAnimation';

export const Doctor = ({ rimIndigoRef, rimTealRef }) => {
  const groupRef = useRef();
  const armLRef = useRef();
  const armRRef = useRef();

  useIdleAnimation(groupRef, rimIndigoRef, rimTealRef, armLRef, armRRef);

  const materials = useMemo(() => ({
    skin: new THREE.MeshStandardMaterial({ color: 0xE7B792, roughness: 0.55 }),
    coat: new THREE.MeshStandardMaterial({ color: 0xFAFBFF, roughness: 0.35, metalness: 0.05 }),
    coatShade: new THREE.MeshStandardMaterial({ color: 0xDCE1F5, roughness: 0.4 }),
    trouser: new THREE.MeshStandardMaterial({ color: 0x3C4A66, roughness: 0.6 }),
    hairMat: new THREE.MeshStandardMaterial({ color: 0x241B14, roughness: 0.5 }),
    hairTieMat: new THREE.MeshStandardMaterial({ color: 0x8B5CF6, roughness: 0.3 }),
    earringMat: new THREE.MeshStandardMaterial({ color: 0x1FC7C0, metalness: 0.8, roughness: 0.2 }),
    metal: new THREE.MeshStandardMaterial({ color: 0xB9C2D6, metalness: 0.7, roughness: 0.3 }),
    shirtBlue: new THREE.MeshStandardMaterial({ color: 0x5B7CF0, roughness: 0.5 }),
  }), []);

  const { skin, coat, coatShade, trouser, hairMat, hairTieMat, earringMat, metal, shirtBlue } = materials;

  return (
    <group ref={groupRef} position={[0, -1.08, 0]} scale={[0.72, 0.72, 0.72]}>
      {/* Head */}
      <mesh position={[0, 3.05, 0]} material={skin}>
        <sphereGeometry args={[0.40, 24, 24]} />
      </mesh>

      {/* Hair */}
      <group name="hair">
        <mesh position={[0, 3.14, 0]} material={hairMat} name="hairCap">
          <sphereGeometry args={[0.42, 24, 24, 0, Math.PI * 2, 0, Math.PI * 0.55]} />
        </mesh>
        <mesh position={[-0.36, 2.92, 0.14]} rotation={[0.2, 0, 0.3]} material={hairMat} name="hairSideL">
          <capsuleGeometry args={[0.065, 0.30, 8, 16]} />
        </mesh>
        <mesh position={[0.36, 2.92, 0.14]} rotation={[0.2, 0, -0.3]} material={hairMat} name="hairSideR">
          <capsuleGeometry args={[0.065, 0.30, 8, 16]} />
        </mesh>
        <mesh position={[0, 3.02, -0.40]} rotation={[0.4, 0, 0]} material={hairTieMat} name="hairTie">
          <torusGeometry args={[0.08, 0.035, 12, 24]} />
        </mesh>
        <mesh position={[0, 2.80, -0.50]} rotation={[0.4, 0, 0]} material={hairMat} name="ponytail">
          <coneGeometry args={[0.14, 0.55, 16]} />
        </mesh>
      </group>

      {/* Earrings */}
      <mesh position={[-0.41, 3.00, 0.06]} material={earringMat}>
        <sphereGeometry args={[0.04, 12, 12]} />
      </mesh>
      <mesh position={[0.41, 3.00, 0.06]} material={earringMat}>
        <sphereGeometry args={[0.04, 12, 12]} />
      </mesh>

      {/* Neck */}
      <mesh position={[0, 2.66, 0]} material={skin}>
        <cylinderGeometry args={[0.14, 0.16, 0.22, 16]} />
      </mesh>

      {/* Torso */}
      <mesh position={[0, 1.95, 0]} material={coat}>
        <cylinderGeometry args={[0.44, 0.52, 1.12, 20]} />
      </mesh>
      <mesh position={[0, 1.38, 0]} scale={[1, 0.55, 0.8]} material={coat}>
        <sphereGeometry args={[0.56, 20, 20]} />
      </mesh>

      {/* Lapels */}
      <mesh position={[-0.16, 2.05, 0.53]} rotation={[0, 0, 0.18]} material={coatShade}>
        <boxGeometry args={[0.16, 0.9, 0.06]} />
      </mesh>
      <mesh position={[0.16, 2.05, 0.53]} rotation={[0, 0, -0.18]} material={coatShade}>
        <boxGeometry args={[0.16, 0.9, 0.06]} />
      </mesh>

      {/* Collar */}
      <mesh position={[0, 2.5, 0.3]} rotation={[0.5, 0, 0]} material={shirtBlue}>
        <coneGeometry args={[0.15, 0.22, 4]} />
      </mesh>

      {/* Left Arm — nested hierarchy */}
      <group ref={armLRef}>
        <mesh position={[0.52, 2.05, 0]} rotation={[0, 0, -0.9]} material={coat}>
          <cylinderGeometry args={[0.13, 0.12, 0.62, 14]} />
          <mesh position={[-0.02, -0.33, 0.28]} rotation={[1.15, 0, -0.25]} material={coat}>
            <cylinderGeometry args={[0.115, 0.10, 0.6, 14]} />
          </mesh>
          <mesh position={[-0.28, -0.39, 0.5]} material={skin}>
            <sphereGeometry args={[0.11, 12, 12]} />
          </mesh>
        </mesh>
      </group>

      {/* Right Arm — nested hierarchy */}
      <group ref={armRRef}>
        <mesh position={[-0.52, 2.05, 0]} rotation={[0, 0, 0.9]} material={coat}>
          <cylinderGeometry args={[0.13, 0.12, 0.62, 14]} />
          <mesh position={[0.02, -0.33, 0.28]} rotation={[1.15, 0, 0.25]} material={coat}>
            <cylinderGeometry args={[0.115, 0.10, 0.6, 14]} />
          </mesh>
          <mesh position={[0.28, -0.39, 0.5]} material={skin}>
            <sphereGeometry args={[0.11, 12, 12]} />
          </mesh>
        </mesh>
      </group>

      {/* Legs */}
      <mesh position={[0.24, 0.35, 0]} material={trouser}>
        <cylinderGeometry args={[0.19, 0.16, 1.3, 16]} />
      </mesh>
      <mesh position={[-0.24, 0.35, 0]} material={trouser}>
        <cylinderGeometry args={[0.19, 0.16, 1.3, 16]} />
      </mesh>

      {/* Shoes */}
      <mesh position={[0.24, -0.35, 0.08]} material={hairMat}>
        <boxGeometry args={[0.24, 0.14, 0.42]} />
      </mesh>
      <mesh position={[-0.24, -0.35, 0.08]} material={hairMat}>
        <boxGeometry args={[0.24, 0.14, 0.42]} />
      </mesh>

      {/* Stethoscope */}
      <mesh position={[0, 2.55, 0.05]} rotation={[1.55, 0, 0.3]} material={metal}>
        <torusGeometry args={[0.28, 0.028, 10, 24, Math.PI * 1.5]} />
      </mesh>
      <mesh position={[0.12, 2.1, 0.42]} rotation={[0.3, 0, 0.15]} material={metal}>
        <cylinderGeometry args={[0.03, 0.03, 0.55, 10]} />
      </mesh>
      <mesh position={[0.18, 1.85, 0.5]} material={metal}>
        <sphereGeometry args={[0.07, 12, 12]} />
      </mesh>

      {/* Shadow disc */}
      <mesh position={[0, -0.47, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[1.15, 32]} />
        <meshBasicMaterial color={0x6D4DE0} transparent opacity={0.12} />
      </mesh>
    </group>
  );
};
